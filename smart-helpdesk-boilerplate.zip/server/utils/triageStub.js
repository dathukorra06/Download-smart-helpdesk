export function classify(text) {
  if (/refund|invoice/.test(text)) return { predictedCategory: "billing", confidence: 0.9 };
  if (/error|bug|stack/.test(text)) return { predictedCategory: "tech", confidence: 0.9 };
  if (/delivery|shipment|package/.test(text)) return { predictedCategory: "shipping", confidence: 0.9 };
  return { predictedCategory: "other", confidence: 0.5 };
}

export function draft(text, articles) {
  const titles = articles.map(a => a.title).join(", ");
  return {
    draftReply: `Based on your query, you might find these useful: ${titles}`,
    citations: articles.map(a => a._id)
  };
}
