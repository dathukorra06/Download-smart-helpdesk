// Example seed script
import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();
mongoose.connect(process.env.MONGO_URI).then(async () => {
  console.log("Seeding DB...");
  // TODO: insert users, KB, tickets
  process.exit();
});
